<?php
$product=$conn->query("SELECT * FROM product");
?>